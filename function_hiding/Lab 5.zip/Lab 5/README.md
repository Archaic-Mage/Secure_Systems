# Readme file for running <PROJECT_NAME>

This readme file provides instructions on how to run the <PROJECT_NAME> project on your local machine.

## Prerequisites
Before you can run the project, you will need to have the VM (the steps for installation are given below) installed on your local machine.

## Installation
The working of the given executable has been tested on the VM (given below), hence run the executable only on the VM.

### Steps to install the VM 
- link to download the VM : https://drive.google.com/file/d/11-syzLq9Z6x7yHXBm7IxleqIrLx4XvLY/view?usp=share_link
### Login credentials <br>
  Username : esCTF <br>
  Password : esctf

## Usage

To run the binary provided, follow these steps:
- Give the inputs in the format specified below
```bash
./fh_sha input1 input2 key
```
 - key to access sum function : <Key>

